gdjs.Main_32gameCode = {};
gdjs.Main_32gameCode.GDNewTiledSpriteObjects1= [];
gdjs.Main_32gameCode.GDNewTiledSpriteObjects2= [];
gdjs.Main_32gameCode.GDNewTiledSpriteObjects3= [];
gdjs.Main_32gameCode.GDNewTiledSpriteObjects4= [];
gdjs.Main_32gameCode.GDNewTiledSprite2Objects1= [];
gdjs.Main_32gameCode.GDNewTiledSprite2Objects2= [];
gdjs.Main_32gameCode.GDNewTiledSprite2Objects3= [];
gdjs.Main_32gameCode.GDNewTiledSprite2Objects4= [];
gdjs.Main_32gameCode.GDFloorObjects1= [];
gdjs.Main_32gameCode.GDFloorObjects2= [];
gdjs.Main_32gameCode.GDFloorObjects3= [];
gdjs.Main_32gameCode.GDFloorObjects4= [];
gdjs.Main_32gameCode.GDShadowObjects1= [];
gdjs.Main_32gameCode.GDShadowObjects2= [];
gdjs.Main_32gameCode.GDShadowObjects3= [];
gdjs.Main_32gameCode.GDShadowObjects4= [];
gdjs.Main_32gameCode.GDNewTextObjects1= [];
gdjs.Main_32gameCode.GDNewTextObjects2= [];
gdjs.Main_32gameCode.GDNewTextObjects3= [];
gdjs.Main_32gameCode.GDNewTextObjects4= [];
gdjs.Main_32gameCode.GDNewText2Objects1= [];
gdjs.Main_32gameCode.GDNewText2Objects2= [];
gdjs.Main_32gameCode.GDNewText2Objects3= [];
gdjs.Main_32gameCode.GDNewText2Objects4= [];
gdjs.Main_32gameCode.GDNewText3Objects1= [];
gdjs.Main_32gameCode.GDNewText3Objects2= [];
gdjs.Main_32gameCode.GDNewText3Objects3= [];
gdjs.Main_32gameCode.GDNewText3Objects4= [];
gdjs.Main_32gameCode.GDBumpyTheRobotObjects1= [];
gdjs.Main_32gameCode.GDBumpyTheRobotObjects2= [];
gdjs.Main_32gameCode.GDBumpyTheRobotObjects3= [];
gdjs.Main_32gameCode.GDBumpyTheRobotObjects4= [];
gdjs.Main_32gameCode.GDMrManObjects1= [];
gdjs.Main_32gameCode.GDMrManObjects2= [];
gdjs.Main_32gameCode.GDMrManObjects3= [];
gdjs.Main_32gameCode.GDMrManObjects4= [];
gdjs.Main_32gameCode.GDFarmerObjects1= [];
gdjs.Main_32gameCode.GDFarmerObjects2= [];
gdjs.Main_32gameCode.GDFarmerObjects3= [];
gdjs.Main_32gameCode.GDFarmerObjects4= [];
gdjs.Main_32gameCode.GDChiChiTheBirdObjects1= [];
gdjs.Main_32gameCode.GDChiChiTheBirdObjects2= [];
gdjs.Main_32gameCode.GDChiChiTheBirdObjects3= [];
gdjs.Main_32gameCode.GDChiChiTheBirdObjects4= [];
gdjs.Main_32gameCode.GDPlatformMidObjects1= [];
gdjs.Main_32gameCode.GDPlatformMidObjects2= [];
gdjs.Main_32gameCode.GDPlatformMidObjects3= [];
gdjs.Main_32gameCode.GDPlatformMidObjects4= [];
gdjs.Main_32gameCode.GDSkyBackgroundObjects1= [];
gdjs.Main_32gameCode.GDSkyBackgroundObjects2= [];
gdjs.Main_32gameCode.GDSkyBackgroundObjects3= [];
gdjs.Main_32gameCode.GDSkyBackgroundObjects4= [];
gdjs.Main_32gameCode.GDBackgroundObjects1= [];
gdjs.Main_32gameCode.GDBackgroundObjects2= [];
gdjs.Main_32gameCode.GDBackgroundObjects3= [];
gdjs.Main_32gameCode.GDBackgroundObjects4= [];
gdjs.Main_32gameCode.GDTilesetPiece13Objects1= [];
gdjs.Main_32gameCode.GDTilesetPiece13Objects2= [];
gdjs.Main_32gameCode.GDTilesetPiece13Objects3= [];
gdjs.Main_32gameCode.GDTilesetPiece13Objects4= [];
gdjs.Main_32gameCode.GDTilesetPiece17Objects1= [];
gdjs.Main_32gameCode.GDTilesetPiece17Objects2= [];
gdjs.Main_32gameCode.GDTilesetPiece17Objects3= [];
gdjs.Main_32gameCode.GDTilesetPiece17Objects4= [];
gdjs.Main_32gameCode.GDTilesetPiece27Objects1= [];
gdjs.Main_32gameCode.GDTilesetPiece27Objects2= [];
gdjs.Main_32gameCode.GDTilesetPiece27Objects3= [];
gdjs.Main_32gameCode.GDTilesetPiece27Objects4= [];
gdjs.Main_32gameCode.GDSteambotObjects1= [];
gdjs.Main_32gameCode.GDSteambotObjects2= [];
gdjs.Main_32gameCode.GDSteambotObjects3= [];
gdjs.Main_32gameCode.GDSteambotObjects4= [];
gdjs.Main_32gameCode.GDHealthBarBoxObjects1= [];
gdjs.Main_32gameCode.GDHealthBarBoxObjects2= [];
gdjs.Main_32gameCode.GDHealthBarBoxObjects3= [];
gdjs.Main_32gameCode.GDHealthBarBoxObjects4= [];
gdjs.Main_32gameCode.GDHealthBarObjects1= [];
gdjs.Main_32gameCode.GDHealthBarObjects2= [];
gdjs.Main_32gameCode.GDHealthBarObjects3= [];
gdjs.Main_32gameCode.GDHealthBarObjects4= [];
gdjs.Main_32gameCode.GDSteambot1Objects1= [];
gdjs.Main_32gameCode.GDSteambot1Objects2= [];
gdjs.Main_32gameCode.GDSteambot1Objects3= [];
gdjs.Main_32gameCode.GDSteambot1Objects4= [];
gdjs.Main_32gameCode.GDSteambot2Objects1= [];
gdjs.Main_32gameCode.GDSteambot2Objects2= [];
gdjs.Main_32gameCode.GDSteambot2Objects3= [];
gdjs.Main_32gameCode.GDSteambot2Objects4= [];
gdjs.Main_32gameCode.GDCaptainObjects1= [];
gdjs.Main_32gameCode.GDCaptainObjects2= [];
gdjs.Main_32gameCode.GDCaptainObjects3= [];
gdjs.Main_32gameCode.GDCaptainObjects4= [];
gdjs.Main_32gameCode.GDSoldiersObjects1= [];
gdjs.Main_32gameCode.GDSoldiersObjects2= [];
gdjs.Main_32gameCode.GDSoldiersObjects3= [];
gdjs.Main_32gameCode.GDSoldiersObjects4= [];
gdjs.Main_32gameCode.GDDialogueBoxObjects1= [];
gdjs.Main_32gameCode.GDDialogueBoxObjects2= [];
gdjs.Main_32gameCode.GDDialogueBoxObjects3= [];
gdjs.Main_32gameCode.GDDialogueBoxObjects4= [];
gdjs.Main_32gameCode.GDStrangerObjects1= [];
gdjs.Main_32gameCode.GDStrangerObjects2= [];
gdjs.Main_32gameCode.GDStrangerObjects3= [];
gdjs.Main_32gameCode.GDStrangerObjects4= [];
gdjs.Main_32gameCode.GDnameTagObjects1= [];
gdjs.Main_32gameCode.GDnameTagObjects2= [];
gdjs.Main_32gameCode.GDnameTagObjects3= [];
gdjs.Main_32gameCode.GDnameTagObjects4= [];
gdjs.Main_32gameCode.GDSelectionObjects1= [];
gdjs.Main_32gameCode.GDSelectionObjects2= [];
gdjs.Main_32gameCode.GDSelectionObjects3= [];
gdjs.Main_32gameCode.GDSelectionObjects4= [];
gdjs.Main_32gameCode.GDDialogue1Objects1= [];
gdjs.Main_32gameCode.GDDialogue1Objects2= [];
gdjs.Main_32gameCode.GDDialogue1Objects3= [];
gdjs.Main_32gameCode.GDDialogue1Objects4= [];
gdjs.Main_32gameCode.GDDialogueOptionsObjects1= [];
gdjs.Main_32gameCode.GDDialogueOptionsObjects2= [];
gdjs.Main_32gameCode.GDDialogueOptionsObjects3= [];
gdjs.Main_32gameCode.GDDialogueOptionsObjects4= [];
gdjs.Main_32gameCode.GDBeggarObjects1= [];
gdjs.Main_32gameCode.GDBeggarObjects2= [];
gdjs.Main_32gameCode.GDBeggarObjects3= [];
gdjs.Main_32gameCode.GDBeggarObjects4= [];
gdjs.Main_32gameCode.GDNewTiledSprite2Objects1= [];
gdjs.Main_32gameCode.GDNewTiledSprite2Objects2= [];
gdjs.Main_32gameCode.GDNewTiledSprite2Objects3= [];
gdjs.Main_32gameCode.GDNewTiledSprite2Objects4= [];
gdjs.Main_32gameCode.GDNewSpriteObjects1= [];
gdjs.Main_32gameCode.GDNewSpriteObjects2= [];
gdjs.Main_32gameCode.GDNewSpriteObjects3= [];
gdjs.Main_32gameCode.GDNewSpriteObjects4= [];
gdjs.Main_32gameCode.GDHouseTallBackgroundObjects1= [];
gdjs.Main_32gameCode.GDHouseTallBackgroundObjects2= [];
gdjs.Main_32gameCode.GDHouseTallBackgroundObjects3= [];
gdjs.Main_32gameCode.GDHouseTallBackgroundObjects4= [];
gdjs.Main_32gameCode.GDNewSprite2Objects1= [];
gdjs.Main_32gameCode.GDNewSprite2Objects2= [];
gdjs.Main_32gameCode.GDNewSprite2Objects3= [];
gdjs.Main_32gameCode.GDNewSprite2Objects4= [];
gdjs.Main_32gameCode.GDDeadarmObjects1= [];
gdjs.Main_32gameCode.GDDeadarmObjects2= [];
gdjs.Main_32gameCode.GDDeadarmObjects3= [];
gdjs.Main_32gameCode.GDDeadarmObjects4= [];
gdjs.Main_32gameCode.GDPlatformLeftSideObjects1= [];
gdjs.Main_32gameCode.GDPlatformLeftSideObjects2= [];
gdjs.Main_32gameCode.GDPlatformLeftSideObjects3= [];
gdjs.Main_32gameCode.GDPlatformLeftSideObjects4= [];
gdjs.Main_32gameCode.GDPlatformRightSideObjects1= [];
gdjs.Main_32gameCode.GDPlatformRightSideObjects2= [];
gdjs.Main_32gameCode.GDPlatformRightSideObjects3= [];
gdjs.Main_32gameCode.GDPlatformRightSideObjects4= [];
gdjs.Main_32gameCode.GDMovingPlatformObjects1= [];
gdjs.Main_32gameCode.GDMovingPlatformObjects2= [];
gdjs.Main_32gameCode.GDMovingPlatformObjects3= [];
gdjs.Main_32gameCode.GDMovingPlatformObjects4= [];
gdjs.Main_32gameCode.GDMovingPlatform2Objects1= [];
gdjs.Main_32gameCode.GDMovingPlatform2Objects2= [];
gdjs.Main_32gameCode.GDMovingPlatform2Objects3= [];
gdjs.Main_32gameCode.GDMovingPlatform2Objects4= [];
gdjs.Main_32gameCode.GDPlatformObjects1= [];
gdjs.Main_32gameCode.GDPlatformObjects2= [];
gdjs.Main_32gameCode.GDPlatformObjects3= [];
gdjs.Main_32gameCode.GDPlatformObjects4= [];
gdjs.Main_32gameCode.GDHouseObjects1= [];
gdjs.Main_32gameCode.GDHouseObjects2= [];
gdjs.Main_32gameCode.GDHouseObjects3= [];
gdjs.Main_32gameCode.GDHouseObjects4= [];
gdjs.Main_32gameCode.GDNewSprite3Objects1= [];
gdjs.Main_32gameCode.GDNewSprite3Objects2= [];
gdjs.Main_32gameCode.GDNewSprite3Objects3= [];
gdjs.Main_32gameCode.GDNewSprite3Objects4= [];
gdjs.Main_32gameCode.GDCogitoObjects1= [];
gdjs.Main_32gameCode.GDCogitoObjects2= [];
gdjs.Main_32gameCode.GDCogitoObjects3= [];
gdjs.Main_32gameCode.GDCogitoObjects4= [];
gdjs.Main_32gameCode.GDOrangeBarrelObjects1= [];
gdjs.Main_32gameCode.GDOrangeBarrelObjects2= [];
gdjs.Main_32gameCode.GDOrangeBarrelObjects3= [];
gdjs.Main_32gameCode.GDOrangeBarrelObjects4= [];
gdjs.Main_32gameCode.GDTilesetPiece6Objects1= [];
gdjs.Main_32gameCode.GDTilesetPiece6Objects2= [];
gdjs.Main_32gameCode.GDTilesetPiece6Objects3= [];
gdjs.Main_32gameCode.GDTilesetPiece6Objects4= [];
gdjs.Main_32gameCode.GDTilesetPiece8Objects1= [];
gdjs.Main_32gameCode.GDTilesetPiece8Objects2= [];
gdjs.Main_32gameCode.GDTilesetPiece8Objects3= [];
gdjs.Main_32gameCode.GDTilesetPiece8Objects4= [];
gdjs.Main_32gameCode.GDSignObjects1= [];
gdjs.Main_32gameCode.GDSignObjects2= [];
gdjs.Main_32gameCode.GDSignObjects3= [];
gdjs.Main_32gameCode.GDSignObjects4= [];
gdjs.Main_32gameCode.GDNewTextObjects1= [];
gdjs.Main_32gameCode.GDNewTextObjects2= [];
gdjs.Main_32gameCode.GDNewTextObjects3= [];
gdjs.Main_32gameCode.GDNewTextObjects4= [];
gdjs.Main_32gameCode.GDNewSprite4Objects1= [];
gdjs.Main_32gameCode.GDNewSprite4Objects2= [];
gdjs.Main_32gameCode.GDNewSprite4Objects3= [];
gdjs.Main_32gameCode.GDNewSprite4Objects4= [];
gdjs.Main_32gameCode.GDsealObjects1= [];
gdjs.Main_32gameCode.GDsealObjects2= [];
gdjs.Main_32gameCode.GDsealObjects3= [];
gdjs.Main_32gameCode.GDsealObjects4= [];
gdjs.Main_32gameCode.GDFadeObjects1= [];
gdjs.Main_32gameCode.GDFadeObjects2= [];
gdjs.Main_32gameCode.GDFadeObjects3= [];
gdjs.Main_32gameCode.GDFadeObjects4= [];
gdjs.Main_32gameCode.GDFade2Objects1= [];
gdjs.Main_32gameCode.GDFade2Objects2= [];
gdjs.Main_32gameCode.GDFade2Objects3= [];
gdjs.Main_32gameCode.GDFade2Objects4= [];


gdjs.Main_32gameCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Main_32gameCode.GDBumpyTheRobotObjects2, gdjs.Main_32gameCode.GDBumpyTheRobotObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32gameCode.GDBumpyTheRobotObjects3.length;i<l;++i) {
    if ( gdjs.Main_32gameCode.GDBumpyTheRobotObjects3[i].getBehavior("PlatformerObject").isOnFloor() ) {
        isConditionTrue_0 = true;
        gdjs.Main_32gameCode.GDBumpyTheRobotObjects3[k] = gdjs.Main_32gameCode.GDBumpyTheRobotObjects3[i];
        ++k;
    }
}
gdjs.Main_32gameCode.GDBumpyTheRobotObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32gameCode.GDBumpyTheRobotObjects3 */
{for(var i = 0, len = gdjs.Main_32gameCode.GDBumpyTheRobotObjects3.length ;i < len;++i) {
    gdjs.Main_32gameCode.GDBumpyTheRobotObjects3[i].setAnimationName("Running");
}
}}

}


{

gdjs.copyArray(gdjs.Main_32gameCode.GDBumpyTheRobotObjects2, gdjs.Main_32gameCode.GDBumpyTheRobotObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32gameCode.GDBumpyTheRobotObjects3.length;i<l;++i) {
    if ( gdjs.Main_32gameCode.GDBumpyTheRobotObjects3[i].getBehavior("PlatformerObject").isJumping() ) {
        isConditionTrue_0 = true;
        gdjs.Main_32gameCode.GDBumpyTheRobotObjects3[k] = gdjs.Main_32gameCode.GDBumpyTheRobotObjects3[i];
        ++k;
    }
}
gdjs.Main_32gameCode.GDBumpyTheRobotObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32gameCode.GDBumpyTheRobotObjects3 */
{for(var i = 0, len = gdjs.Main_32gameCode.GDBumpyTheRobotObjects3.length ;i < len;++i) {
    gdjs.Main_32gameCode.GDBumpyTheRobotObjects3[i].setAnimationName("Jumping");
}
}}

}


{

/* Reuse gdjs.Main_32gameCode.GDBumpyTheRobotObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32gameCode.GDBumpyTheRobotObjects2.length;i<l;++i) {
    if ( gdjs.Main_32gameCode.GDBumpyTheRobotObjects2[i].getBehavior("PlatformerObject").isFalling() ) {
        isConditionTrue_0 = true;
        gdjs.Main_32gameCode.GDBumpyTheRobotObjects2[k] = gdjs.Main_32gameCode.GDBumpyTheRobotObjects2[i];
        ++k;
    }
}
gdjs.Main_32gameCode.GDBumpyTheRobotObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32gameCode.GDBumpyTheRobotObjects2 */
{for(var i = 0, len = gdjs.Main_32gameCode.GDBumpyTheRobotObjects2.length ;i < len;++i) {
    gdjs.Main_32gameCode.GDBumpyTheRobotObjects2[i].setAnimationName("Falling");
}
}}

}


};gdjs.Main_32gameCode.eventsList1 = function(runtimeScene) {

{

/* Reuse gdjs.Main_32gameCode.GDBumpyTheRobotObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32gameCode.GDBumpyTheRobotObjects2.length;i<l;++i) {
    if ( gdjs.Main_32gameCode.GDBumpyTheRobotObjects2[i].getBehavior("PlatformerObject").isOnFloor() ) {
        isConditionTrue_0 = true;
        gdjs.Main_32gameCode.GDBumpyTheRobotObjects2[k] = gdjs.Main_32gameCode.GDBumpyTheRobotObjects2[i];
        ++k;
    }
}
gdjs.Main_32gameCode.GDBumpyTheRobotObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32gameCode.GDBumpyTheRobotObjects2 */
{for(var i = 0, len = gdjs.Main_32gameCode.GDBumpyTheRobotObjects2.length ;i < len;++i) {
    gdjs.Main_32gameCode.GDBumpyTheRobotObjects2[i].setAnimationName("Idle");
}
}}

}


};gdjs.Main_32gameCode.eventsList2 = function(runtimeScene) {

};gdjs.Main_32gameCode.eventsList3 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("BumpyTheRobot"), gdjs.Main_32gameCode.GDBumpyTheRobotObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32gameCode.GDBumpyTheRobotObjects2.length;i<l;++i) {
    if ( gdjs.Main_32gameCode.GDBumpyTheRobotObjects2[i].getBehavior("PlatformerObject").isMovingEvenALittle() ) {
        isConditionTrue_0 = true;
        gdjs.Main_32gameCode.GDBumpyTheRobotObjects2[k] = gdjs.Main_32gameCode.GDBumpyTheRobotObjects2[i];
        ++k;
    }
}
gdjs.Main_32gameCode.GDBumpyTheRobotObjects2.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.Main_32gameCode.eventsList0(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("BumpyTheRobot"), gdjs.Main_32gameCode.GDBumpyTheRobotObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32gameCode.GDBumpyTheRobotObjects2.length;i<l;++i) {
    if ( !(gdjs.Main_32gameCode.GDBumpyTheRobotObjects2[i].getBehavior("PlatformerObject").isMovingEvenALittle()) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32gameCode.GDBumpyTheRobotObjects2[k] = gdjs.Main_32gameCode.GDBumpyTheRobotObjects2[i];
        ++k;
    }
}
gdjs.Main_32gameCode.GDBumpyTheRobotObjects2.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.Main_32gameCode.eventsList1(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("BumpyTheRobot"), gdjs.Main_32gameCode.GDBumpyTheRobotObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32gameCode.GDBumpyTheRobotObjects2.length;i<l;++i) {
    if ( gdjs.Main_32gameCode.GDBumpyTheRobotObjects2[i].getBehavior("PlatformerObject").isUsingControl("Left") ) {
        isConditionTrue_0 = true;
        gdjs.Main_32gameCode.GDBumpyTheRobotObjects2[k] = gdjs.Main_32gameCode.GDBumpyTheRobotObjects2[i];
        ++k;
    }
}
gdjs.Main_32gameCode.GDBumpyTheRobotObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32gameCode.GDBumpyTheRobotObjects2 */
{for(var i = 0, len = gdjs.Main_32gameCode.GDBumpyTheRobotObjects2.length ;i < len;++i) {
    gdjs.Main_32gameCode.GDBumpyTheRobotObjects2[i].flipX(true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("BumpyTheRobot"), gdjs.Main_32gameCode.GDBumpyTheRobotObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32gameCode.GDBumpyTheRobotObjects2.length;i<l;++i) {
    if ( gdjs.Main_32gameCode.GDBumpyTheRobotObjects2[i].getBehavior("PlatformerObject").isUsingControl("Right") ) {
        isConditionTrue_0 = true;
        gdjs.Main_32gameCode.GDBumpyTheRobotObjects2[k] = gdjs.Main_32gameCode.GDBumpyTheRobotObjects2[i];
        ++k;
    }
}
gdjs.Main_32gameCode.GDBumpyTheRobotObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32gameCode.GDBumpyTheRobotObjects2 */
{for(var i = 0, len = gdjs.Main_32gameCode.GDBumpyTheRobotObjects2.length ;i < len;++i) {
    gdjs.Main_32gameCode.GDBumpyTheRobotObjects2[i].flipX(false);
}
}}

}


{


gdjs.Main_32gameCode.eventsList2(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("BumpyTheRobot"), gdjs.Main_32gameCode.GDBumpyTheRobotObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32gameCode.GDBumpyTheRobotObjects1.length;i<l;++i) {
    if ( gdjs.Main_32gameCode.GDBumpyTheRobotObjects1[i].getBehavior("PlatformerObject").isJumping() ) {
        isConditionTrue_0 = true;
        gdjs.Main_32gameCode.GDBumpyTheRobotObjects1[k] = gdjs.Main_32gameCode.GDBumpyTheRobotObjects1[i];
        ++k;
    }
}
gdjs.Main_32gameCode.GDBumpyTheRobotObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(10331068);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "d32cb297988f21b74f7f893fff28430f0198b3c1f8a6c0622520e9158b284d3f_jump.aac", false, 50, 1);
}}

}


};gdjs.Main_32gameCode.eventsList4 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 3, "", 0);
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("BumpyTheRobot"), gdjs.Main_32gameCode.GDBumpyTheRobotObjects1);
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.Main_32gameCode.GDBumpyTheRobotObjects1.length !== 0 ? gdjs.Main_32gameCode.GDBumpyTheRobotObjects1[0] : null), true, "", 0);
}}

}


};gdjs.Main_32gameCode.eventsList5 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Steambot"), gdjs.Main_32gameCode.GDSteambotObjects1);
{for(var i = 0, len = gdjs.Main_32gameCode.GDSteambotObjects1.length ;i < len;++i) {
    gdjs.Main_32gameCode.GDSteambotObjects1[i].flipX(true);
}
}}

}


};gdjs.Main_32gameCode.eventsList6 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playMusic(runtimeScene, "kim-lightyear-leave-the-world-tonight-chiptune-edit-loop-132102.mp3", true, 50, 1);
}}

}


{


let isConditionTrue_0 = false;
{
}

}


};gdjs.Main_32gameCode.mapOfGDgdjs_46Main_9532gameCode_46GDBumpyTheRobotObjects2Objects = Hashtable.newFrom({"BumpyTheRobot": gdjs.Main_32gameCode.GDBumpyTheRobotObjects2});
gdjs.Main_32gameCode.mapOfGDgdjs_46Main_9532gameCode_46GDSteambotObjects2Objects = Hashtable.newFrom({"Steambot": gdjs.Main_32gameCode.GDSteambotObjects2});
gdjs.Main_32gameCode.mapOfGDgdjs_46Main_9532gameCode_46GDBumpyTheRobotObjects2Objects = Hashtable.newFrom({"BumpyTheRobot": gdjs.Main_32gameCode.GDBumpyTheRobotObjects2});
gdjs.Main_32gameCode.mapOfGDgdjs_46Main_9532gameCode_46GDSteambotObjects2Objects = Hashtable.newFrom({"Steambot": gdjs.Main_32gameCode.GDSteambotObjects2});
gdjs.Main_32gameCode.eventsList7 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "scrollText") >= gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2));
if (isConditionTrue_0) {
{gdjs.dialogueTree.scrollClippedText();
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "scrollText");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "x");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.dialogueTree.hasClippedScrollingCompleted();
}
if (isConditionTrue_0) {
{gdjs.dialogueTree.goToNextDialogueLine();
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.dialogueTree.hasClippedScrollingCompleted());
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(2).setNumber(0.04);
}}

}


};gdjs.Main_32gameCode.eventsList8 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "Up");
if (isConditionTrue_0) {
{gdjs.dialogueTree.selectNextOption();
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "Down");
if (isConditionTrue_0) {
{gdjs.dialogueTree.selectPreviousOption();
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "z");
if (isConditionTrue_0) {
{gdjs.dialogueTree.confirmSelectOption();
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.dialogueTree.hasSelectedOptionChanged();
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32gameCode.GDDialogueOptionsObjects2 */
{for(var i = 0, len = gdjs.Main_32gameCode.GDDialogueOptionsObjects2.length ;i < len;++i) {
    gdjs.Main_32gameCode.GDDialogueOptionsObjects2[i].setString(gdjs.dialogueTree.getLineOptionsTextVertical(">"));
}
}}

}


};gdjs.Main_32gameCode.mapOfGDgdjs_46Main_9532gameCode_46GDBumpyTheRobotObjects3Objects = Hashtable.newFrom({"BumpyTheRobot": gdjs.Main_32gameCode.GDBumpyTheRobotObjects3});
gdjs.Main_32gameCode.mapOfGDgdjs_46Main_9532gameCode_46GDNewSprite2Objects3Objects = Hashtable.newFrom({"NewSprite2": gdjs.Main_32gameCode.GDNewSprite2Objects3});
gdjs.Main_32gameCode.mapOfGDgdjs_46Main_9532gameCode_46GDBumpyTheRobotObjects3Objects = Hashtable.newFrom({"BumpyTheRobot": gdjs.Main_32gameCode.GDBumpyTheRobotObjects3});
gdjs.Main_32gameCode.mapOfGDgdjs_46Main_9532gameCode_46GDNewSprite2Objects3Objects = Hashtable.newFrom({"NewSprite2": gdjs.Main_32gameCode.GDNewSprite2Objects3});
gdjs.Main_32gameCode.eventsList9 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("BumpyTheRobot"), gdjs.Main_32gameCode.GDBumpyTheRobotObjects3);
gdjs.copyArray(runtimeScene.getObjects("NewSprite2"), gdjs.Main_32gameCode.GDNewSprite2Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "z");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1)) == 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.dialogueTree.isRunning());
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Main_32gameCode.mapOfGDgdjs_46Main_9532gameCode_46GDBumpyTheRobotObjects3Objects, gdjs.Main_32gameCode.mapOfGDgdjs_46Main_9532gameCode_46GDNewSprite2Objects3Objects, false, runtimeScene, false);
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "scrollText");
}{gdjs.dialogueTree.startFrom("Crusty");
}{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("BumpyTheRobot"), gdjs.Main_32gameCode.GDBumpyTheRobotObjects3);
gdjs.copyArray(runtimeScene.getObjects("NewSprite2"), gdjs.Main_32gameCode.GDNewSprite2Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "z");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1)) == 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.dialogueTree.isRunning());
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Main_32gameCode.mapOfGDgdjs_46Main_9532gameCode_46GDBumpyTheRobotObjects3Objects, gdjs.Main_32gameCode.mapOfGDgdjs_46Main_9532gameCode_46GDNewSprite2Objects3Objects, false, runtimeScene, false);
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "scrollText");
}{gdjs.dialogueTree.startFrom("Crusty2");
}}

}


{


let isConditionTrue_0 = false;
{
}

}


};gdjs.Main_32gameCode.mapOfGDgdjs_46Main_9532gameCode_46GDBumpyTheRobotObjects3Objects = Hashtable.newFrom({"BumpyTheRobot": gdjs.Main_32gameCode.GDBumpyTheRobotObjects3});
gdjs.Main_32gameCode.mapOfGDgdjs_46Main_9532gameCode_46GDCogitoObjects3Objects = Hashtable.newFrom({"Cogito": gdjs.Main_32gameCode.GDCogitoObjects3});
gdjs.Main_32gameCode.mapOfGDgdjs_46Main_9532gameCode_46GDBumpyTheRobotObjects2Objects = Hashtable.newFrom({"BumpyTheRobot": gdjs.Main_32gameCode.GDBumpyTheRobotObjects2});
gdjs.Main_32gameCode.mapOfGDgdjs_46Main_9532gameCode_46GDCogitoObjects2Objects = Hashtable.newFrom({"Cogito": gdjs.Main_32gameCode.GDCogitoObjects2});
gdjs.Main_32gameCode.eventsList10 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("BumpyTheRobot"), gdjs.Main_32gameCode.GDBumpyTheRobotObjects3);
gdjs.copyArray(runtimeScene.getObjects("Cogito"), gdjs.Main_32gameCode.GDCogitoObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "z");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) == 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.dialogueTree.isRunning());
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Main_32gameCode.mapOfGDgdjs_46Main_9532gameCode_46GDBumpyTheRobotObjects3Objects, gdjs.Main_32gameCode.mapOfGDgdjs_46Main_9532gameCode_46GDCogitoObjects3Objects, false, runtimeScene, false);
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "scrollText");
}{gdjs.dialogueTree.startFrom("cogito");
}{runtimeScene.getGame().getVariables().getFromIndex(3).setNumber(1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("BumpyTheRobot"), gdjs.Main_32gameCode.GDBumpyTheRobotObjects2);
gdjs.copyArray(runtimeScene.getObjects("Cogito"), gdjs.Main_32gameCode.GDCogitoObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "z");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) == 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.dialogueTree.isRunning());
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Main_32gameCode.mapOfGDgdjs_46Main_9532gameCode_46GDBumpyTheRobotObjects2Objects, gdjs.Main_32gameCode.mapOfGDgdjs_46Main_9532gameCode_46GDCogitoObjects2Objects, false, runtimeScene, false);
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "scrollText");
}{gdjs.dialogueTree.startFrom("cogito2");
}}

}


};gdjs.Main_32gameCode.mapOfGDgdjs_46Main_9532gameCode_46GDBumpyTheRobotObjects3Objects = Hashtable.newFrom({"BumpyTheRobot": gdjs.Main_32gameCode.GDBumpyTheRobotObjects3});
gdjs.Main_32gameCode.mapOfGDgdjs_46Main_9532gameCode_46GDCaptainObjects3Objects = Hashtable.newFrom({"Captain": gdjs.Main_32gameCode.GDCaptainObjects3});
gdjs.Main_32gameCode.mapOfGDgdjs_46Main_9532gameCode_46GDBumpyTheRobotObjects2Objects = Hashtable.newFrom({"BumpyTheRobot": gdjs.Main_32gameCode.GDBumpyTheRobotObjects2});
gdjs.Main_32gameCode.mapOfGDgdjs_46Main_9532gameCode_46GDCaptainObjects2Objects = Hashtable.newFrom({"Captain": gdjs.Main_32gameCode.GDCaptainObjects2});
gdjs.Main_32gameCode.eventsList11 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("BumpyTheRobot"), gdjs.Main_32gameCode.GDBumpyTheRobotObjects3);
gdjs.copyArray(runtimeScene.getObjects("Captain"), gdjs.Main_32gameCode.GDCaptainObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "z");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)) == 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.dialogueTree.isRunning());
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Main_32gameCode.mapOfGDgdjs_46Main_9532gameCode_46GDBumpyTheRobotObjects3Objects, gdjs.Main_32gameCode.mapOfGDgdjs_46Main_9532gameCode_46GDCaptainObjects3Objects, false, runtimeScene, false);
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "scrollText");
}{gdjs.dialogueTree.startFrom("laf");
}{runtimeScene.getGame().getVariables().getFromIndex(4).setNumber(1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("BumpyTheRobot"), gdjs.Main_32gameCode.GDBumpyTheRobotObjects2);
gdjs.copyArray(runtimeScene.getObjects("Captain"), gdjs.Main_32gameCode.GDCaptainObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "z");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)) == 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.dialogueTree.isRunning());
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Main_32gameCode.mapOfGDgdjs_46Main_9532gameCode_46GDBumpyTheRobotObjects2Objects, gdjs.Main_32gameCode.mapOfGDgdjs_46Main_9532gameCode_46GDCaptainObjects2Objects, false, runtimeScene, false);
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "scrollText");
}{gdjs.dialogueTree.startFrom("laf2");
}}

}


};gdjs.Main_32gameCode.mapOfGDgdjs_46Main_9532gameCode_46GDBumpyTheRobotObjects1Objects = Hashtable.newFrom({"BumpyTheRobot": gdjs.Main_32gameCode.GDBumpyTheRobotObjects1});
gdjs.Main_32gameCode.mapOfGDgdjs_46Main_9532gameCode_46GDSteambot1Objects1Objects = Hashtable.newFrom({"Steambot1": gdjs.Main_32gameCode.GDSteambot1Objects1});
gdjs.Main_32gameCode.eventsList12 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("BumpyTheRobot"), gdjs.Main_32gameCode.GDBumpyTheRobotObjects1);
gdjs.copyArray(runtimeScene.getObjects("Steambot1"), gdjs.Main_32gameCode.GDSteambot1Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "z");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5)) == 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.dialogueTree.isRunning());
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Main_32gameCode.mapOfGDgdjs_46Main_9532gameCode_46GDBumpyTheRobotObjects1Objects, gdjs.Main_32gameCode.mapOfGDgdjs_46Main_9532gameCode_46GDSteambot1Objects1Objects, false, runtimeScene, false);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32gameCode.GDSteambot1Objects1 */
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "scrollText");
}{gdjs.dialogueTree.startFrom("EndBot");
}{runtimeScene.getGame().getVariables().getFromIndex(5).setNumber(1);
}{for(var i = 0, len = gdjs.Main_32gameCode.GDSteambot1Objects1.length ;i < len;++i) {
    gdjs.Main_32gameCode.GDSteambot1Objects1[i].flipX(true);
}
}}

}


};gdjs.Main_32gameCode.eventsList13 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Dialogue1"), gdjs.Main_32gameCode.GDDialogue1Objects2);
gdjs.copyArray(runtimeScene.getObjects("DialogueBox"), gdjs.Main_32gameCode.GDDialogueBoxObjects2);
gdjs.copyArray(runtimeScene.getObjects("DialogueOptions"), gdjs.Main_32gameCode.GDDialogueOptionsObjects2);
gdjs.copyArray(runtimeScene.getObjects("Selection"), gdjs.Main_32gameCode.GDSelectionObjects2);
gdjs.copyArray(runtimeScene.getObjects("nameTag"), gdjs.Main_32gameCode.GDnameTagObjects2);
{for(var i = 0, len = gdjs.Main_32gameCode.GDDialogueBoxObjects2.length ;i < len;++i) {
    gdjs.Main_32gameCode.GDDialogueBoxObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.Main_32gameCode.GDDialogue1Objects2.length ;i < len;++i) {
    gdjs.Main_32gameCode.GDDialogue1Objects2[i].hide();
}
}{for(var i = 0, len = gdjs.Main_32gameCode.GDDialogueOptionsObjects2.length ;i < len;++i) {
    gdjs.Main_32gameCode.GDDialogueOptionsObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.Main_32gameCode.GDSelectionObjects2.length ;i < len;++i) {
    gdjs.Main_32gameCode.GDSelectionObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.Main_32gameCode.GDnameTagObjects2.length ;i < len;++i) {
    gdjs.Main_32gameCode.GDnameTagObjects2[i].hide();
}
}{gdjs.dialogueTree.loadFromJsonFile(runtimeScene, "Steam bot intro");
}{gdjs.dialogueTree.loadFromJsonFile(runtimeScene, "Crusty");
}{gdjs.dialogueTree.loadFromJsonFile(runtimeScene, "Cogito");
}{gdjs.dialogueTree.loadFromJsonFile(runtimeScene, "Laf");
}{gdjs.dialogueTree.loadFromJsonFile(runtimeScene, "No");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.dialogueTree.isRunning();
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("BumpyTheRobot"), gdjs.Main_32gameCode.GDBumpyTheRobotObjects2);
gdjs.copyArray(runtimeScene.getObjects("Dialogue1"), gdjs.Main_32gameCode.GDDialogue1Objects2);
gdjs.copyArray(runtimeScene.getObjects("DialogueBox"), gdjs.Main_32gameCode.GDDialogueBoxObjects2);
gdjs.copyArray(runtimeScene.getObjects("nameTag"), gdjs.Main_32gameCode.GDnameTagObjects2);
{for(var i = 0, len = gdjs.Main_32gameCode.GDDialogue1Objects2.length ;i < len;++i) {
    gdjs.Main_32gameCode.GDDialogue1Objects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.Main_32gameCode.GDDialogueBoxObjects2.length ;i < len;++i) {
    gdjs.Main_32gameCode.GDDialogueBoxObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.Main_32gameCode.GDnameTagObjects2.length ;i < len;++i) {
    gdjs.Main_32gameCode.GDnameTagObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.Main_32gameCode.GDBumpyTheRobotObjects2.length ;i < len;++i) {
    gdjs.Main_32gameCode.GDBumpyTheRobotObjects2[i].activateBehavior("PlatformerObject", false);
}
}{for(var i = 0, len = gdjs.Main_32gameCode.GDBumpyTheRobotObjects2.length ;i < len;++i) {
    gdjs.Main_32gameCode.GDBumpyTheRobotObjects2[i].getBehavior("PlatformerObject").setCurrentSpeed(0);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "x");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.dialogueTree.isRunning());
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "scrollText") >= 0.5;
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("BumpyTheRobot"), gdjs.Main_32gameCode.GDBumpyTheRobotObjects2);
gdjs.copyArray(runtimeScene.getObjects("Dialogue1"), gdjs.Main_32gameCode.GDDialogue1Objects2);
gdjs.copyArray(runtimeScene.getObjects("DialogueBox"), gdjs.Main_32gameCode.GDDialogueBoxObjects2);
gdjs.copyArray(runtimeScene.getObjects("nameTag"), gdjs.Main_32gameCode.GDnameTagObjects2);
{for(var i = 0, len = gdjs.Main_32gameCode.GDDialogue1Objects2.length ;i < len;++i) {
    gdjs.Main_32gameCode.GDDialogue1Objects2[i].hide();
}
}{for(var i = 0, len = gdjs.Main_32gameCode.GDDialogueBoxObjects2.length ;i < len;++i) {
    gdjs.Main_32gameCode.GDDialogueBoxObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.Main_32gameCode.GDBumpyTheRobotObjects2.length ;i < len;++i) {
    gdjs.Main_32gameCode.GDBumpyTheRobotObjects2[i].activateBehavior("PlatformerObject", true);
}
}{for(var i = 0, len = gdjs.Main_32gameCode.GDnameTagObjects2.length ;i < len;++i) {
    gdjs.Main_32gameCode.GDnameTagObjects2[i].setAnimationName("none");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.dialogueTree.isCommandCalled("name");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("nameTag"), gdjs.Main_32gameCode.GDnameTagObjects2);
{for(var i = 0, len = gdjs.Main_32gameCode.GDnameTagObjects2.length ;i < len;++i) {
    gdjs.Main_32gameCode.GDnameTagObjects2[i].setAnimationName(gdjs.dialogueTree.getCommandParameter(0));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("BumpyTheRobot"), gdjs.Main_32gameCode.GDBumpyTheRobotObjects2);
gdjs.copyArray(runtimeScene.getObjects("Steambot"), gdjs.Main_32gameCode.GDSteambotObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "z");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.dialogueTree.isRunning());
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Main_32gameCode.mapOfGDgdjs_46Main_9532gameCode_46GDBumpyTheRobotObjects2Objects, gdjs.Main_32gameCode.mapOfGDgdjs_46Main_9532gameCode_46GDSteambotObjects2Objects, false, runtimeScene, false);
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "scrollText");
}{gdjs.dialogueTree.startFrom("First");
}{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("BumpyTheRobot"), gdjs.Main_32gameCode.GDBumpyTheRobotObjects2);
gdjs.copyArray(runtimeScene.getObjects("Steambot"), gdjs.Main_32gameCode.GDSteambotObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "z");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.dialogueTree.isRunning());
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Main_32gameCode.mapOfGDgdjs_46Main_9532gameCode_46GDBumpyTheRobotObjects2Objects, gdjs.Main_32gameCode.mapOfGDgdjs_46Main_9532gameCode_46GDSteambotObjects2Objects, false, runtimeScene, false);
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "scrollText");
}{gdjs.dialogueTree.startFrom("Second");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.dialogueTree.isDialogueLineType("text");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Dialogue1"), gdjs.Main_32gameCode.GDDialogue1Objects2);
{for(var i = 0, len = gdjs.Main_32gameCode.GDDialogue1Objects2.length ;i < len;++i) {
    gdjs.Main_32gameCode.GDDialogue1Objects2[i].setString(gdjs.dialogueTree.getClippedLineText());
}
}
{ //Subevents
gdjs.Main_32gameCode.eventsList7(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.dialogueTree.isDialogueLineType("options"));
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("DialogueOptions"), gdjs.Main_32gameCode.GDDialogueOptionsObjects2);
{for(var i = 0, len = gdjs.Main_32gameCode.GDDialogueOptionsObjects2.length ;i < len;++i) {
    gdjs.Main_32gameCode.GDDialogueOptionsObjects2[i].hide();
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.dialogueTree.isDialogueLineType("options");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("DialogueOptions"), gdjs.Main_32gameCode.GDDialogueOptionsObjects2);
{for(var i = 0, len = gdjs.Main_32gameCode.GDDialogueOptionsObjects2.length ;i < len;++i) {
    gdjs.Main_32gameCode.GDDialogueOptionsObjects2[i].hide(false);
}
}
{ //Subevents
gdjs.Main_32gameCode.eventsList8(runtimeScene);} //End of subevents
}

}


{


gdjs.Main_32gameCode.eventsList9(runtimeScene);
}


{


gdjs.Main_32gameCode.eventsList10(runtimeScene);
}


{


gdjs.Main_32gameCode.eventsList11(runtimeScene);
}


{


gdjs.Main_32gameCode.eventsList12(runtimeScene);
}


};gdjs.Main_32gameCode.eventsList14 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)) == 0;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("MovingPlatform2"), gdjs.Main_32gameCode.GDMovingPlatform2Objects2);
{for(var i = 0, len = gdjs.Main_32gameCode.GDMovingPlatform2Objects2.length ;i < len;++i) {
    gdjs.Main_32gameCode.GDMovingPlatform2Objects2[i].activateBehavior("RectangleMovement", false);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)) == 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.dialogueTree.isRunning());
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("MovingPlatform2"), gdjs.Main_32gameCode.GDMovingPlatform2Objects1);
{for(var i = 0, len = gdjs.Main_32gameCode.GDMovingPlatform2Objects1.length ;i < len;++i) {
    gdjs.Main_32gameCode.GDMovingPlatform2Objects1[i].activateBehavior("RectangleMovement", true);
}
}}

}


};gdjs.Main_32gameCode.eventsList15 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Fade"), gdjs.Main_32gameCode.GDFadeObjects2);
{for(var i = 0, len = gdjs.Main_32gameCode.GDFadeObjects2.length ;i < len;++i) {
    gdjs.Main_32gameCode.GDFadeObjects2[i].setOpacity(gdjs.Main_32gameCode.GDFadeObjects2[i].getOpacity() - (1.5));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DialogueBox"), gdjs.Main_32gameCode.GDDialogueBoxObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5)) == 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.dialogueTree.isRunning());
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32gameCode.GDDialogueBoxObjects2.length;i<l;++i) {
    if ( !(gdjs.Main_32gameCode.GDDialogueBoxObjects2[i].isVisible()) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32gameCode.GDDialogueBoxObjects2[k] = gdjs.Main_32gameCode.GDDialogueBoxObjects2[i];
        ++k;
    }
}
gdjs.Main_32gameCode.GDDialogueBoxObjects2.length = k;
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("BumpyTheRobot"), gdjs.Main_32gameCode.GDBumpyTheRobotObjects2);
gdjs.copyArray(runtimeScene.getObjects("Fade2"), gdjs.Main_32gameCode.GDFade2Objects2);
{for(var i = 0, len = gdjs.Main_32gameCode.GDFade2Objects2.length ;i < len;++i) {
    gdjs.Main_32gameCode.GDFade2Objects2[i].setOpacity(gdjs.Main_32gameCode.GDFade2Objects2[i].getOpacity() + (1.5));
}
}{for(var i = 0, len = gdjs.Main_32gameCode.GDBumpyTheRobotObjects2.length ;i < len;++i) {
    gdjs.Main_32gameCode.GDBumpyTheRobotObjects2[i].activateBehavior("PlatformerObject", false);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Fade2"), gdjs.Main_32gameCode.GDFade2Objects2);
{for(var i = 0, len = gdjs.Main_32gameCode.GDFade2Objects2.length ;i < len;++i) {
    gdjs.Main_32gameCode.GDFade2Objects2[i].setOpacity(0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Fade2"), gdjs.Main_32gameCode.GDFade2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32gameCode.GDFade2Objects1.length;i<l;++i) {
    if ( gdjs.Main_32gameCode.GDFade2Objects1[i].getOpacity() >= 255 ) {
        isConditionTrue_0 = true;
        gdjs.Main_32gameCode.GDFade2Objects1[k] = gdjs.Main_32gameCode.GDFade2Objects1[i];
        ++k;
    }
}
gdjs.Main_32gameCode.GDFade2Objects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "EndCredits", false);
}}

}


};gdjs.Main_32gameCode.eventsList16 = function(runtimeScene) {

{


gdjs.Main_32gameCode.eventsList3(runtimeScene);
}


{


gdjs.Main_32gameCode.eventsList4(runtimeScene);
}


{


gdjs.Main_32gameCode.eventsList5(runtimeScene);
}


{


gdjs.Main_32gameCode.eventsList6(runtimeScene);
}


{


gdjs.Main_32gameCode.eventsList13(runtimeScene);
}


{


gdjs.Main_32gameCode.eventsList14(runtimeScene);
}


{


gdjs.Main_32gameCode.eventsList15(runtimeScene);
}


};

gdjs.Main_32gameCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Main_32gameCode.GDNewTiledSpriteObjects1.length = 0;
gdjs.Main_32gameCode.GDNewTiledSpriteObjects2.length = 0;
gdjs.Main_32gameCode.GDNewTiledSpriteObjects3.length = 0;
gdjs.Main_32gameCode.GDNewTiledSpriteObjects4.length = 0;
gdjs.Main_32gameCode.GDNewTiledSprite2Objects1.length = 0;
gdjs.Main_32gameCode.GDNewTiledSprite2Objects2.length = 0;
gdjs.Main_32gameCode.GDNewTiledSprite2Objects3.length = 0;
gdjs.Main_32gameCode.GDNewTiledSprite2Objects4.length = 0;
gdjs.Main_32gameCode.GDFloorObjects1.length = 0;
gdjs.Main_32gameCode.GDFloorObjects2.length = 0;
gdjs.Main_32gameCode.GDFloorObjects3.length = 0;
gdjs.Main_32gameCode.GDFloorObjects4.length = 0;
gdjs.Main_32gameCode.GDShadowObjects1.length = 0;
gdjs.Main_32gameCode.GDShadowObjects2.length = 0;
gdjs.Main_32gameCode.GDShadowObjects3.length = 0;
gdjs.Main_32gameCode.GDShadowObjects4.length = 0;
gdjs.Main_32gameCode.GDNewTextObjects1.length = 0;
gdjs.Main_32gameCode.GDNewTextObjects2.length = 0;
gdjs.Main_32gameCode.GDNewTextObjects3.length = 0;
gdjs.Main_32gameCode.GDNewTextObjects4.length = 0;
gdjs.Main_32gameCode.GDNewText2Objects1.length = 0;
gdjs.Main_32gameCode.GDNewText2Objects2.length = 0;
gdjs.Main_32gameCode.GDNewText2Objects3.length = 0;
gdjs.Main_32gameCode.GDNewText2Objects4.length = 0;
gdjs.Main_32gameCode.GDNewText3Objects1.length = 0;
gdjs.Main_32gameCode.GDNewText3Objects2.length = 0;
gdjs.Main_32gameCode.GDNewText3Objects3.length = 0;
gdjs.Main_32gameCode.GDNewText3Objects4.length = 0;
gdjs.Main_32gameCode.GDBumpyTheRobotObjects1.length = 0;
gdjs.Main_32gameCode.GDBumpyTheRobotObjects2.length = 0;
gdjs.Main_32gameCode.GDBumpyTheRobotObjects3.length = 0;
gdjs.Main_32gameCode.GDBumpyTheRobotObjects4.length = 0;
gdjs.Main_32gameCode.GDMrManObjects1.length = 0;
gdjs.Main_32gameCode.GDMrManObjects2.length = 0;
gdjs.Main_32gameCode.GDMrManObjects3.length = 0;
gdjs.Main_32gameCode.GDMrManObjects4.length = 0;
gdjs.Main_32gameCode.GDFarmerObjects1.length = 0;
gdjs.Main_32gameCode.GDFarmerObjects2.length = 0;
gdjs.Main_32gameCode.GDFarmerObjects3.length = 0;
gdjs.Main_32gameCode.GDFarmerObjects4.length = 0;
gdjs.Main_32gameCode.GDChiChiTheBirdObjects1.length = 0;
gdjs.Main_32gameCode.GDChiChiTheBirdObjects2.length = 0;
gdjs.Main_32gameCode.GDChiChiTheBirdObjects3.length = 0;
gdjs.Main_32gameCode.GDChiChiTheBirdObjects4.length = 0;
gdjs.Main_32gameCode.GDPlatformMidObjects1.length = 0;
gdjs.Main_32gameCode.GDPlatformMidObjects2.length = 0;
gdjs.Main_32gameCode.GDPlatformMidObjects3.length = 0;
gdjs.Main_32gameCode.GDPlatformMidObjects4.length = 0;
gdjs.Main_32gameCode.GDSkyBackgroundObjects1.length = 0;
gdjs.Main_32gameCode.GDSkyBackgroundObjects2.length = 0;
gdjs.Main_32gameCode.GDSkyBackgroundObjects3.length = 0;
gdjs.Main_32gameCode.GDSkyBackgroundObjects4.length = 0;
gdjs.Main_32gameCode.GDBackgroundObjects1.length = 0;
gdjs.Main_32gameCode.GDBackgroundObjects2.length = 0;
gdjs.Main_32gameCode.GDBackgroundObjects3.length = 0;
gdjs.Main_32gameCode.GDBackgroundObjects4.length = 0;
gdjs.Main_32gameCode.GDTilesetPiece13Objects1.length = 0;
gdjs.Main_32gameCode.GDTilesetPiece13Objects2.length = 0;
gdjs.Main_32gameCode.GDTilesetPiece13Objects3.length = 0;
gdjs.Main_32gameCode.GDTilesetPiece13Objects4.length = 0;
gdjs.Main_32gameCode.GDTilesetPiece17Objects1.length = 0;
gdjs.Main_32gameCode.GDTilesetPiece17Objects2.length = 0;
gdjs.Main_32gameCode.GDTilesetPiece17Objects3.length = 0;
gdjs.Main_32gameCode.GDTilesetPiece17Objects4.length = 0;
gdjs.Main_32gameCode.GDTilesetPiece27Objects1.length = 0;
gdjs.Main_32gameCode.GDTilesetPiece27Objects2.length = 0;
gdjs.Main_32gameCode.GDTilesetPiece27Objects3.length = 0;
gdjs.Main_32gameCode.GDTilesetPiece27Objects4.length = 0;
gdjs.Main_32gameCode.GDSteambotObjects1.length = 0;
gdjs.Main_32gameCode.GDSteambotObjects2.length = 0;
gdjs.Main_32gameCode.GDSteambotObjects3.length = 0;
gdjs.Main_32gameCode.GDSteambotObjects4.length = 0;
gdjs.Main_32gameCode.GDHealthBarBoxObjects1.length = 0;
gdjs.Main_32gameCode.GDHealthBarBoxObjects2.length = 0;
gdjs.Main_32gameCode.GDHealthBarBoxObjects3.length = 0;
gdjs.Main_32gameCode.GDHealthBarBoxObjects4.length = 0;
gdjs.Main_32gameCode.GDHealthBarObjects1.length = 0;
gdjs.Main_32gameCode.GDHealthBarObjects2.length = 0;
gdjs.Main_32gameCode.GDHealthBarObjects3.length = 0;
gdjs.Main_32gameCode.GDHealthBarObjects4.length = 0;
gdjs.Main_32gameCode.GDSteambot1Objects1.length = 0;
gdjs.Main_32gameCode.GDSteambot1Objects2.length = 0;
gdjs.Main_32gameCode.GDSteambot1Objects3.length = 0;
gdjs.Main_32gameCode.GDSteambot1Objects4.length = 0;
gdjs.Main_32gameCode.GDSteambot2Objects1.length = 0;
gdjs.Main_32gameCode.GDSteambot2Objects2.length = 0;
gdjs.Main_32gameCode.GDSteambot2Objects3.length = 0;
gdjs.Main_32gameCode.GDSteambot2Objects4.length = 0;
gdjs.Main_32gameCode.GDCaptainObjects1.length = 0;
gdjs.Main_32gameCode.GDCaptainObjects2.length = 0;
gdjs.Main_32gameCode.GDCaptainObjects3.length = 0;
gdjs.Main_32gameCode.GDCaptainObjects4.length = 0;
gdjs.Main_32gameCode.GDSoldiersObjects1.length = 0;
gdjs.Main_32gameCode.GDSoldiersObjects2.length = 0;
gdjs.Main_32gameCode.GDSoldiersObjects3.length = 0;
gdjs.Main_32gameCode.GDSoldiersObjects4.length = 0;
gdjs.Main_32gameCode.GDDialogueBoxObjects1.length = 0;
gdjs.Main_32gameCode.GDDialogueBoxObjects2.length = 0;
gdjs.Main_32gameCode.GDDialogueBoxObjects3.length = 0;
gdjs.Main_32gameCode.GDDialogueBoxObjects4.length = 0;
gdjs.Main_32gameCode.GDStrangerObjects1.length = 0;
gdjs.Main_32gameCode.GDStrangerObjects2.length = 0;
gdjs.Main_32gameCode.GDStrangerObjects3.length = 0;
gdjs.Main_32gameCode.GDStrangerObjects4.length = 0;
gdjs.Main_32gameCode.GDnameTagObjects1.length = 0;
gdjs.Main_32gameCode.GDnameTagObjects2.length = 0;
gdjs.Main_32gameCode.GDnameTagObjects3.length = 0;
gdjs.Main_32gameCode.GDnameTagObjects4.length = 0;
gdjs.Main_32gameCode.GDSelectionObjects1.length = 0;
gdjs.Main_32gameCode.GDSelectionObjects2.length = 0;
gdjs.Main_32gameCode.GDSelectionObjects3.length = 0;
gdjs.Main_32gameCode.GDSelectionObjects4.length = 0;
gdjs.Main_32gameCode.GDDialogue1Objects1.length = 0;
gdjs.Main_32gameCode.GDDialogue1Objects2.length = 0;
gdjs.Main_32gameCode.GDDialogue1Objects3.length = 0;
gdjs.Main_32gameCode.GDDialogue1Objects4.length = 0;
gdjs.Main_32gameCode.GDDialogueOptionsObjects1.length = 0;
gdjs.Main_32gameCode.GDDialogueOptionsObjects2.length = 0;
gdjs.Main_32gameCode.GDDialogueOptionsObjects3.length = 0;
gdjs.Main_32gameCode.GDDialogueOptionsObjects4.length = 0;
gdjs.Main_32gameCode.GDBeggarObjects1.length = 0;
gdjs.Main_32gameCode.GDBeggarObjects2.length = 0;
gdjs.Main_32gameCode.GDBeggarObjects3.length = 0;
gdjs.Main_32gameCode.GDBeggarObjects4.length = 0;
gdjs.Main_32gameCode.GDNewTiledSprite2Objects1.length = 0;
gdjs.Main_32gameCode.GDNewTiledSprite2Objects2.length = 0;
gdjs.Main_32gameCode.GDNewTiledSprite2Objects3.length = 0;
gdjs.Main_32gameCode.GDNewTiledSprite2Objects4.length = 0;
gdjs.Main_32gameCode.GDNewSpriteObjects1.length = 0;
gdjs.Main_32gameCode.GDNewSpriteObjects2.length = 0;
gdjs.Main_32gameCode.GDNewSpriteObjects3.length = 0;
gdjs.Main_32gameCode.GDNewSpriteObjects4.length = 0;
gdjs.Main_32gameCode.GDHouseTallBackgroundObjects1.length = 0;
gdjs.Main_32gameCode.GDHouseTallBackgroundObjects2.length = 0;
gdjs.Main_32gameCode.GDHouseTallBackgroundObjects3.length = 0;
gdjs.Main_32gameCode.GDHouseTallBackgroundObjects4.length = 0;
gdjs.Main_32gameCode.GDNewSprite2Objects1.length = 0;
gdjs.Main_32gameCode.GDNewSprite2Objects2.length = 0;
gdjs.Main_32gameCode.GDNewSprite2Objects3.length = 0;
gdjs.Main_32gameCode.GDNewSprite2Objects4.length = 0;
gdjs.Main_32gameCode.GDDeadarmObjects1.length = 0;
gdjs.Main_32gameCode.GDDeadarmObjects2.length = 0;
gdjs.Main_32gameCode.GDDeadarmObjects3.length = 0;
gdjs.Main_32gameCode.GDDeadarmObjects4.length = 0;
gdjs.Main_32gameCode.GDPlatformLeftSideObjects1.length = 0;
gdjs.Main_32gameCode.GDPlatformLeftSideObjects2.length = 0;
gdjs.Main_32gameCode.GDPlatformLeftSideObjects3.length = 0;
gdjs.Main_32gameCode.GDPlatformLeftSideObjects4.length = 0;
gdjs.Main_32gameCode.GDPlatformRightSideObjects1.length = 0;
gdjs.Main_32gameCode.GDPlatformRightSideObjects2.length = 0;
gdjs.Main_32gameCode.GDPlatformRightSideObjects3.length = 0;
gdjs.Main_32gameCode.GDPlatformRightSideObjects4.length = 0;
gdjs.Main_32gameCode.GDMovingPlatformObjects1.length = 0;
gdjs.Main_32gameCode.GDMovingPlatformObjects2.length = 0;
gdjs.Main_32gameCode.GDMovingPlatformObjects3.length = 0;
gdjs.Main_32gameCode.GDMovingPlatformObjects4.length = 0;
gdjs.Main_32gameCode.GDMovingPlatform2Objects1.length = 0;
gdjs.Main_32gameCode.GDMovingPlatform2Objects2.length = 0;
gdjs.Main_32gameCode.GDMovingPlatform2Objects3.length = 0;
gdjs.Main_32gameCode.GDMovingPlatform2Objects4.length = 0;
gdjs.Main_32gameCode.GDPlatformObjects1.length = 0;
gdjs.Main_32gameCode.GDPlatformObjects2.length = 0;
gdjs.Main_32gameCode.GDPlatformObjects3.length = 0;
gdjs.Main_32gameCode.GDPlatformObjects4.length = 0;
gdjs.Main_32gameCode.GDHouseObjects1.length = 0;
gdjs.Main_32gameCode.GDHouseObjects2.length = 0;
gdjs.Main_32gameCode.GDHouseObjects3.length = 0;
gdjs.Main_32gameCode.GDHouseObjects4.length = 0;
gdjs.Main_32gameCode.GDNewSprite3Objects1.length = 0;
gdjs.Main_32gameCode.GDNewSprite3Objects2.length = 0;
gdjs.Main_32gameCode.GDNewSprite3Objects3.length = 0;
gdjs.Main_32gameCode.GDNewSprite3Objects4.length = 0;
gdjs.Main_32gameCode.GDCogitoObjects1.length = 0;
gdjs.Main_32gameCode.GDCogitoObjects2.length = 0;
gdjs.Main_32gameCode.GDCogitoObjects3.length = 0;
gdjs.Main_32gameCode.GDCogitoObjects4.length = 0;
gdjs.Main_32gameCode.GDOrangeBarrelObjects1.length = 0;
gdjs.Main_32gameCode.GDOrangeBarrelObjects2.length = 0;
gdjs.Main_32gameCode.GDOrangeBarrelObjects3.length = 0;
gdjs.Main_32gameCode.GDOrangeBarrelObjects4.length = 0;
gdjs.Main_32gameCode.GDTilesetPiece6Objects1.length = 0;
gdjs.Main_32gameCode.GDTilesetPiece6Objects2.length = 0;
gdjs.Main_32gameCode.GDTilesetPiece6Objects3.length = 0;
gdjs.Main_32gameCode.GDTilesetPiece6Objects4.length = 0;
gdjs.Main_32gameCode.GDTilesetPiece8Objects1.length = 0;
gdjs.Main_32gameCode.GDTilesetPiece8Objects2.length = 0;
gdjs.Main_32gameCode.GDTilesetPiece8Objects3.length = 0;
gdjs.Main_32gameCode.GDTilesetPiece8Objects4.length = 0;
gdjs.Main_32gameCode.GDSignObjects1.length = 0;
gdjs.Main_32gameCode.GDSignObjects2.length = 0;
gdjs.Main_32gameCode.GDSignObjects3.length = 0;
gdjs.Main_32gameCode.GDSignObjects4.length = 0;
gdjs.Main_32gameCode.GDNewTextObjects1.length = 0;
gdjs.Main_32gameCode.GDNewTextObjects2.length = 0;
gdjs.Main_32gameCode.GDNewTextObjects3.length = 0;
gdjs.Main_32gameCode.GDNewTextObjects4.length = 0;
gdjs.Main_32gameCode.GDNewSprite4Objects1.length = 0;
gdjs.Main_32gameCode.GDNewSprite4Objects2.length = 0;
gdjs.Main_32gameCode.GDNewSprite4Objects3.length = 0;
gdjs.Main_32gameCode.GDNewSprite4Objects4.length = 0;
gdjs.Main_32gameCode.GDsealObjects1.length = 0;
gdjs.Main_32gameCode.GDsealObjects2.length = 0;
gdjs.Main_32gameCode.GDsealObjects3.length = 0;
gdjs.Main_32gameCode.GDsealObjects4.length = 0;
gdjs.Main_32gameCode.GDFadeObjects1.length = 0;
gdjs.Main_32gameCode.GDFadeObjects2.length = 0;
gdjs.Main_32gameCode.GDFadeObjects3.length = 0;
gdjs.Main_32gameCode.GDFadeObjects4.length = 0;
gdjs.Main_32gameCode.GDFade2Objects1.length = 0;
gdjs.Main_32gameCode.GDFade2Objects2.length = 0;
gdjs.Main_32gameCode.GDFade2Objects3.length = 0;
gdjs.Main_32gameCode.GDFade2Objects4.length = 0;

gdjs.Main_32gameCode.eventsList16(runtimeScene);

return;

}

gdjs['Main_32gameCode'] = gdjs.Main_32gameCode;
